from django.contrib import admin
from profiles.models import Doctor,DoctorType,Patient
# Register your models here.
admin.site.register(Doctor)
admin.site.register(DoctorType)
admin.site.register(Patient)
# Register your models here.
